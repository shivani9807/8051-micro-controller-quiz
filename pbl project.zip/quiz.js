// pos is position of where the user in the test or which question they're up to
var pos = 0, test, test_status, question, choice, choices, chA, chB, chC, correct = 0;
// this is a multidimensional array with 4 inner array elements with 5 elements inside them
var questions = [
  {
      question: "Which of the ports act as the 16-bit address lines for transferring data through it?",
      a: "PORT 0 and PORT 1",
      b: "PORT 1 and PORT 2",
      c: "PORT 0 and PORT 2",
      answer: "C"
    },
  {
      question: "The port 0 can sink ______ number of TTL inputs when a logic 0 is sent to a port line as an output port ",
      a: "2",
      b: "4",
      c: "8",
      answer: "C"
    },
  {
      question: "To initialize any port as an output port what value is to be given to it?",
      a: "A port is by default an output port",
      b: "0xFF",
      c: "0x01",
      answer: "A"
    },
  {
      question: "Which of the following signal is set to 1, if no data is transmitted?",
      a: "READY",
      b: "STOP",
      c: "TXD",
      answer: "C"
    },
 {
      question: "What does UART stand for?",
      a: "unique asynchronous receiver transmitter",
      b: "universal address receiver transmitter",
      c: "universal asynchronous receiver transmitter",
      answer: "C"
    },
 {
      question: "What rate can define the timing in the UART?",
      a: "bit rate",
      b: "baud rate",
      c: "voltage rate",
      answer: "B"
    },
 {
      question: "How may parallel I/O ports does 8051 have?",
      a: "4",
      b: "5",
      c: "3",
      answer: "A"
    },
 {
      question: "How much total external data memory can be interfaced to the 8051?",
      a: "32K",
      b: "16K",
      c: "64K",
      answer: "C"
    },
 {
      question: "Which are the bit-addressable memory locations?",
      a: "10H through 1FH",
      b: "30H through 3FH",
      c: "20H through 2FH",
      answer: "C"
    },
 {
      question: "HIGH on which pin resets the 8051 microcontroller?",
      a: "RESET",
      b: "STOP",
      c: "RST",
      answer: "C"
    }
  ];
// this get function is short for the getElementById function  
function get(x){
  return document.getElementById(x);
}
// this function renders a question for display on the page
function renderQuestion(){
  test = get("test");
  if(pos >= questions.length){
    test.innerHTML = "<h2>You got "+correct+" of "+questions.length+" questions correct</h2>";
    get("test_status").innerHTML = "Test completed";
    // resets the variable to allow users to restart the test
    pos = 0;
    correct = 0;
    // stops rest of renderQuestion function running when test is completed
    return false;
  }
  get("test_status").innerHTML = "Question "+(pos+1)+" of "+questions.length;
  
  question = questions[pos].question;
  chA = questions[pos].a;
  chB = questions[pos].b;
  chC = questions[pos].c;
  // display the question
  test.innerHTML = "<h3>"+question+"</h3>";
  // display the answer options
  // the += appends to the data we started on the line above
  test.innerHTML += "<label> <input type='radio' name='choices' value='A'> "+chA+"</label><br>";
  test.innerHTML += "<label> <input type='radio' name='choices' value='B'> "+chB+"</label><br>";
  test.innerHTML += "<label> <input type='radio' name='choices' value='C'> "+chC+"</label><br><br>";
  test.innerHTML += "<button onclick='checkAnswer()'>Submit Answer</button>";
}
function checkAnswer(){
  // use getElementsByName because we have an array which it will loop through
  choices = document.getElementsByName("choices");
  for(var i=0; i<choices.length; i++){
    if(choices[i].checked){
      choice = choices[i].value;
    }
  }
  // checks if answer matches the correct choice
  if(choice == questions[pos].answer){
    //each time there is a correct answer this value increases
    correct++;
  }
  // changes position of which character user is on
  pos++;
  // then the renderQuestion function runs again to go to next question
  renderQuestion();


}
// Add event listener to call renderQuestion on page load event
window.addEventListener("load", renderQuestion);